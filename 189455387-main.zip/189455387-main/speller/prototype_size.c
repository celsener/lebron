unsigned int size(void)
{
    // TODO
    if (load(dictionary))
    {
        unsigned int counter = 0;
        node *ptr = NULL;
        for (int i = 0; i < N; i++)
        {
            if (table[i] != NULL)
            {
                ptr = table[i];
            }
            while (ptr != NULL)
            {
                counter++;
                ptr = ptr->next;
            }
        }
        return counter;
    }
    else
    {
        return 0;
    }
}
