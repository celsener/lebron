// Implements a dictionary's functionality

#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
} node;

// TODO: Choose number of buckets in hash table
const unsigned int N = 17576;

unsigned int counter = 0;
bool loaded = false;

// Hash table
node *table[N];

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    // TODO
    int l = strlen(word);
    char copy[l + 1];
    for (int i = 0; i < l + 1; i++)
    {
        copy[i] = 0;
    }
    char hashword[4] = {0};
    for (int k = 0; k < 3 && k < l; k++)
    {
        hashword[k] = word[k];
    }
    if (l == 1)
    {
        hashword[1] = 'A';
        hashword[2] = 'A';
    }
    else if (l == 2)
    {
        hashword[2] = 'A';
    }
    for (int i = 0; i < l; i++)
    {
        if (word[i] == '\'')
        {
            hashword[i] = 'A';
        }
        copy[i] = tolower(word[i]);
    }
    copy[l] = '\0';
    int p = hash(hashword);
    node *ptr = table[p];
    while (ptr != NULL)
    {
        if (strcmp(ptr->word, copy) == 0)
        {
            return true;
        }
        ptr = ptr->next;
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // TODO: Improve this hash function
    int position = (toupper(word[0]) - 'A') * pow(26, 2) + (toupper(word[1]) - 'A') * 26 + (toupper(word[2]) - 'A');
    return position;
}

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    // TODO
    FILE *source = fopen(dictionary, "r");
    if (source == NULL)
    {
        printf("Source problem\n");
        return false;
    }
    char c;
    char words[46] = {0};
    words[45] = '\0';
    int i = 0;
    while (fread(&c, sizeof(char), 1, source))
    {
        if (isalpha(c) || c == '\'')
        {
            if (i < 45)
            {
                words[i] = c;
                i++;
            }
            else
            {
                printf("array words[i] overflow\n");
            }
        }
        else
        {
            counter++;
            // Set rest of word (if < 3) and ' to A aka 0
            char tmpword[4] = {0};
            for (int k = 0; k < 4; k++)
            {
                tmpword[k] = words[k];
            }
            if (i < 3)
            {
                tmpword[i] = 'A';
                tmpword[i + 1] = 'A';
            }
            for (int l = 0; l < 3; l++)
            {
                if (words[l] == '\'')
                {
                    tmpword[l] = 'A';
                }
            }
            // Get the position of the word
            int p = hash(tmpword);
            // Create new node
            node *n = malloc(sizeof(node));
            for (int k = 0; k < 46; k++)
            {
                n->word[k] = '\0';
            }
            if (n == NULL)
            {
                fclose(source);
                printf("Malloc problem\n");
                return false;
            }
            for (int j = 0; j < i; j++)
            {
                n->word[j] = words[j];
            }
            n->word[strlen(n->word)] = '\0';
            n->next = NULL;
            // Append new node to the front of table at position [p]
            n->next = table[p];
            table[p] = n;
            i = 0;
        }
    }
    fclose(source);
    loaded = true;
    return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    if (loaded)
    {
        return counter;
    }
    else
    {
        return 0;
    }
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    // TODO
    for (int i = 0; i < N; i++)
    {
        node *ptr = table[i];
        while (ptr != NULL)
        {
            node *tmp = ptr;
            ptr = ptr->next;
            free(tmp);
        }
    }
    return true;
}
