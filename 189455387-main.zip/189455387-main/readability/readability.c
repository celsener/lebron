#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

float gradefloat(string text);

int main(void)
{
    // Promt for a text input.
    string paragraph = get_string("Text: ");

    // Calculate the Grade.
    float index = gradefloat(paragraph);

    // Round to the correct integer.
    int grade = round(index);

    // Give answer.
    if (grade > 15)
    {
        printf("Grade 16+\n");
    }
    else if (grade < 0)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade %i\n", grade);
    }
}

float gradefloat(string text)
{
    // find out L, S & words
    float letters = 0;
    float sentences = 0;
    float words = 1;
    int j = 0;

    for (int i = 0; i < strlen(text); i++)
    {
        if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            sentences++;
        }
        else if (text[i] == ' ')
        {
            words++;
        }
        else
        {
            if (isalpha(text[i]))
            {
                letters++;
            }
        }
    }
    float L = ((letters / words) * 100);
    float S = ((sentences / words) * 100);

    // calculate Grade Level
    float index = 0.0588 * L - 0.296 * S - 15.8;
    return index;
}
