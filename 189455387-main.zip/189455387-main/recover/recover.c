#include <cs50.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef uint8_t BYTE;
typedef BYTE block[512];
bool jpgcheck(block b);

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./recover [NameOfPicture]");
        return 1;
    }
    FILE *card = fopen(argv[1], "r");
    if (card == NULL)
    {
        printf("Error could not open file\n");
        return 2;
    }

    BYTE b;
    block blck;
    int counter = 0;
    bool check = false;
    FILE *jpg = NULL;
    char *filenames[50] = {
        "000.jpg", "001.jpg", "002.jpg", "003.jpg", "004.jpg", "005.jpg", "006.jpg", "007.jpg",
        "008.jpg", "009.jpg", "010.jpg", "011.jpg", "012.jpg", "013.jpg", "014.jpg", "015.jpg",
        "016.jpg", "017.jpg", "018.jpg", "019.jpg", "020.jpg", "021.jpg", "022.jpg", "023.jpg",
        "024.jpg", "025.jpg", "026.jpg", "027.jpg", "028.jpg", "029.jpg", "030.jpg", "031.jpg",
        "032.jpg", "033.jpg", "034.jpg", "035.jpg", "036.jpg", "037.jpg", "038.jpg", "039.jpg",
        "040.jpg", "041.jpg", "042.jpg", "043.jpg", "044.jpg", "045.jpg", "046.jpg", "047.jpg",
        "048.jpg", "049.jpg"};

    while (fread(&blck, sizeof(blck), 1, card))
    {
        if (jpgcheck(blck))
        {
            if (jpg != NULL)
            {
                fclose(jpg);
            }
            counter++;
            char filename[7];
            sprintf(filename, "%s", filenames[counter - 1]);
            jpg = fopen(filename, "w");
            if (jpg == NULL)
            {
                printf("Error: Could not open JPG File");
                fclose(card);
                return 3;
            }
            if (jpg != NULL)
            {
                fwrite(&blck, sizeof(blck), 1, jpg);
                check = true;
            }
        }
        else
        {
            if (check)
            {
                fwrite(&blck, sizeof(blck), 1, jpg);
            }
        }
    }

    if (jpg != NULL)
    {
        fclose(jpg);
    }
    fclose(card);
}

bool jpgcheck(block b)
{
    return b[0] == 255 && b[1] == 216 && b[2] == 255 && b[3] > 223 && b[3] < 240;
}
