#include <cs50.h>
#include <stdio.h>

int main(void)
{
    long number = get_long("Number: ");
    long front = number;
    long length = 2;
    // check first two digits
    while (front >= 100)
    {
        front /= 10;
        length++;
    }
    long multi = 0;
    long rest = 0;
    long sdig = 0;
    for (long i = length; i > 0; i--)
    {
        rest += (number % 10);
        number /= 10;
        sdig = (2 * (number % 10));
        if (sdig > 9)
        {
            multi += (sdig % 10);
            sdig /= 10;
            multi += sdig;
        }
        else
        {
            multi += sdig;
        }
        number /= 10;
    }
    long sum = (rest + multi);
    if ((sum % 10) == 0)
    {
        if (front == 37 || front == 39)
        {
            if (length == 15)
            {
                printf("AMEX\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
        else if ((front / 10) == 4)
        {
            if (length == 13 || length == 16)
            {
                printf("VISA\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
        else if (front > 50 && front < 56)
        {
            if (length == 16)
            {
                printf("MASTERCARD\n");
            }
            else
            {
                printf("INVALID\n");
            }
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }
}
