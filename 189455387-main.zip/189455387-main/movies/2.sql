SELECT birth FROM people WHERE name = 'Emma Stone';
