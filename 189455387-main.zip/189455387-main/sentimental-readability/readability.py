from cs50 import get_string


def main():
    paragraph = get_string("Text: ")

    index = gradefloat(paragraph)

    grade = round(index)

    if grade > 15:
        print("Grade 16+")
    elif grade < 0:
        print("Before Grade 1")
    else:
        print(f"Grade {grade}")


def gradefloat(text):
    letters = 0
    sentences = 0
    words = 1
    j = 0

    for i in range(len(text)):
        if text[i] == '.' or text[i] == '!' or text[i] == '?':
            sentences += 1
        elif text[i] == ' ':
            words += 1
        elif text[i].isalpha():
            letters += 1

    L = (letters / words) * 100
    S = (sentences / words) * 100

    index = 0.0588 * L - 0.296 * S - 15.8
    return index


main()
