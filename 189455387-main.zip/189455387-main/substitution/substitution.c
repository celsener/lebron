#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int testarg(string key);
string cipher(string text, string key);

int main(int argc, string argv[])
{
    // Checks if the key is valid.
    if (argc == 2)
    {
        if (testarg(argv[1]) != 0)
        {
            printf("INVALID KEY\n");
            return 1;
        }
    }
    else
    {
        printf("INVALID: MUST GIVE EXACTLY ONE COMMAND-LINE ARGUMENT.\n");
        return 1;
    }
    // Take input: Plaintext
    string plaintext = get_string("plaintext: ");

    // Encrypt the Plaintext to ciphertext
    printf("ciphertext: %s\n", cipher(plaintext, argv[1]));
    return 0;
}

string cipher(string text, string key)
{
    int len = strlen(text);
    char *citext = malloc(len + 1);
    char alphabet[26];
    for (int i = 0; i < 26; i++)
    {
        alphabet[i] = (char) (97 + i);
    }
    char ALPHABET[26];
    for (int i = 0; i < 26; i++)
    {
        ALPHABET[i] = (char) (65 + i);
    }
    while (text[len] != '\0')
    {
        len++;
    }
    for (int j = 0; j < len; j++)
    {
        if (isalpha(text[j]))
        {
            for (int k = 0; k < 26; k++)
            {
                if (text[j] == alphabet[k])
                {
                    citext[j] = tolower(key[k]);
                }
                else if (text[j] == ALPHABET[k])
                {
                    citext[j] = toupper(key[k]);
                }
            }
        }
        else
        {
            citext[j] = text[j];
        }
    }
    return citext;
}

int testarg(string key)
{
    int n = 0;
    while (key[n] != '\0')
    {
        n++;
    }
    if (n != 26)
    {
        return 1;
    }
    else
    {
        int alphacount[26] = {0};
        // Test argument: length (26), every letter once, alphabetic of course
        char alphabet[26];
        for (int i = 0; i < 26; i++)
        {
            alphabet[i] = (char) (65 + i);
        }

        // All 26 letters of the key
        for (int j = 0; j < 26; j++)
        {
            // Test all the letters in the alphabet
            for (int k = 0; k < 26; k++)
            {
                if (toupper(key[j]) == alphabet[k])
                {
                    if (alphacount[k] == 1)
                    {
                        return 2;
                    }
                    else
                    {
                        alphacount[k] = 1;
                    }
                }
            }
        }

        int sum = 0;
        for (int m = 0; m < 26; m++)
        {
            sum += alphacount[m];
        }
        if (sum != 26)
        {
            return 3;
        }
        else
        {
            return 0;
        }
    }
}
