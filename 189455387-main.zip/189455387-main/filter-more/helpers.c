#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            BYTE average =
                round((image[i][j].rgbtBlue + image[i][j].rgbtGreen + image[i][j].rgbtRed) / 3.0);
            image[i][j].rgbtBlue = average;
            image[i][j].rgbtGreen = average;
            image[i][j].rgbtRed = average;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < (width / 2); j++)
        {
            RGBTRIPLE tmp = image[i][j];
            image[i][j] = image[i][(width - j) - 1];
            image[i][(width - j) - 1] = tmp;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE tmp[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            tmp[i][j] = image[i][j];
        }
    }
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int average = 0;
            float counter = 0;
            for (int k = -1; k <= 1; k++)
            {
                for (int h = -1; h <= 1; h++)
                {
                    if ((i + k) >= 0 && (i + k) < height && (j + h) >= 0 && (j + h) < width)
                    {
                        average += tmp[i + k][j + h].rgbtBlue;
                        counter++;
                    }
                }
            }
            average = round(average / counter);
            image[i][j].rgbtBlue = average;

            average = 0;
            counter = 0;
            for (int k = -1; k <= 1; k++)
            {
                for (int h = -1; h <= 1; h++)
                {
                    if ((i + k) >= 0 && (i + k) < height && (j + h) >= 0 && (j + h) < width)
                    {
                        average += tmp[i + k][j + h].rgbtGreen;
                        counter++;
                    }
                }
            }
            average = round(average / counter);
            image[i][j].rgbtGreen = average;

            average = 0;
            counter = 0;
            for (int k = -1; k <= 1; k++)
            {
                for (int h = -1; h <= 1; h++)
                {
                    if ((i + k) >= 0 && (i + k) < height && (j + h) >= 0 && (j + h) < width)
                    {
                        average += tmp[i + k][j + h].rgbtRed;
                        counter++;
                    }
                }
            }
            average = round(average / counter);
            image[i][j].rgbtRed = average;
        }
    }
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE tmp[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            tmp[i][j] = image[i][j];
        }
    }
    //Gx
    int gx[3][3] ={
        {-1, 0, 1},
        {-2, 0, 2},
        {-1, 0, 1}
    };
    //Gy
    int gy[3][3] ={
        {-1, -2, -1},
        {0, 0, 0},
        {1, 2, 1}
    };
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int gx_wsumblue = 0;
            int gx_wsumgreen = 0;
            int gx_wsumred = 0;
            int gy_wsumblue = 0;
            int gy_wsumgreen = 0;
            int gy_wsumred = 0;
            for (int k = -1; k <= 1; k++)
            {
                for (int h = -1; h <= 1; h++)
                {
                    if ((i + k) >= 0 && (i + k) < height && (j + h) >= 0 && (j + h) < width)
                    {
                        gx_wsumblue += (tmp[i + k][j + h].rgbtBlue * gx[k + 1][h + 1]);
                        gx_wsumgreen += (tmp[i + k][j + h].rgbtGreen * gx[k + 1][h + 1]);
                        gx_wsumred += (tmp[i + k][j + h].rgbtRed * gx[k + 1][h + 1]);
                        gy_wsumblue += (tmp[i + k][j + h].rgbtBlue * gy[k + 1][h + 1]);
                        gy_wsumgreen += (tmp[i + k][j + h].rgbtGreen * gy[k + 1][h + 1]);
                        gy_wsumred += (tmp[i + k][j + h].rgbtRed * gy[k + 1][h + 1]);
                    }
                }
            }
            int gtotalblue = 0;
            int gtotalgreen = 0;
            int gtotalred = 0;
            int magnitudeblue = round(sqrt(pow(gx_wsumblue, 2) + pow(gy_wsumblue, 2)));
            int magnitudegreen = round(sqrt(pow(gx_wsumgreen, 2) + pow(gy_wsumgreen, 2)));
            int magnitudered = round(sqrt(pow(gx_wsumred, 2) + pow(gy_wsumred, 2)));

            if (magnitudeblue > 255)
            {
                gtotalblue = 255;
            }
            else
            {
                gtotalblue = magnitudeblue;
            }
            if (magnitudegreen > 255)
            {
                gtotalgreen = 255;
            }
            else
            {
                gtotalgreen = magnitudegreen;
            }
            if (magnitudered > 255)
            {
                gtotalred = 255;
            }
            else
            {
                gtotalred = magnitudered;
            }
            image[i][j].rgbtBlue = gtotalblue;
            image[i][j].rgbtGreen = gtotalgreen;
            image[i][j].rgbtRed = gtotalred;
        }
    }
    return;
}
