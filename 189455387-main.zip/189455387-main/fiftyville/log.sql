-- Keep a log of any SQL queries you execute as you solve the mystery.
.schema --Get a overview of all the tables and information available
-- Known Information: 28. July 2024, Humphrey Street

SELECT street FROM crime_scene_reports WHERE year = 2024 AND month = 7 AND day = 28 AND street = 'Humphrey Street';
--10:15 am
--At bakery
--Interviews with 3 wintesses (28.7.2024)
--Interviews mention bakery

SELECT transcript FROM interviews WHERE year = 2024 AND month = 7 AND day = 28 AND transcript LIKE '%bakery%';
--0-10 minutes after theft -> thief drove away
--Thief withdrew money at Leggett Street morning of 28.7.24
--Thief leaving bakery -> called someone (less than 60s) ->
--          planning to take earliest flight out of fiftyville at 29.7.24 -> asked complice to purchase flight ticket

SELECT activity, license_plate FROM bakery_security_logs WHERE year = 2024 AND month = 7 AND day = 28 AND hour = 10 AND minute < 26 AND minute > 14;
--All exit so it has to be one of these licence_plates

SELECT account_number, amount FROM atm_transactions WHERE year = 2024 AND month = 7 AND day = 28 AND transaction_type = 'withdraw' AND atm_location = 'Leggett Street';
--Suscpect's Account Number and amount of withdraw among results

SELECT receiver, caller FROM phone_calls WHERE year = 2024 AND month = 7 AND day = 28 AND duration < 60;
-- Caller = Thief
-- Receiver = Complice

SELECT city FROM airports WHERE id = (
    SELECT destination_airport_id FROM flights
        WHERE year = 2024 AND month = 7 AND day = 29
        AND origin_airport_id = (SELECT id FROM airports WHERE city = 'Fiftyville') ORDER BY hour LIMIT 1);
--New York City

SELECT passport_number FROM passengers
    WHERE flight_id IN
        (SELECT id FROM flights WHERE year = 2024 AND month = 7 AND day = 29 AND origin_airport_id =
        (SELECT id FROM airports WHERE city = 'Fiftyville') ORDER BY hour LIMIT 1);
--Passport number of suspect must be among them

SELECT person_id FROM bank_accounts
WHERE account_number IN
(SELECT account_number FROM atm_transactions WHERE year = 2024 AND month = 7 AND day = 28
AND transaction_type = 'withdraw' AND atm_location = 'Leggett Street');
--Suspects person_id must be among them


SELECT name FROM people
    WHERE phone_number IN (SELECT caller FROM phone_calls WHERE year = 2024 AND month = 7 AND day = 28 AND duration < 60)
    AND license_plate IN (SELECT license_plate FROM bakery_security_logs WHERE year = 2024 AND month = 7 AND day = 28 AND hour = 10 AND minute < 26 AND minute > 14)
    AND id IN (SELECT person_id FROM bank_accounts WHERE account_number IN (SELECT account_number FROM atm_transactions WHERE year = 2024 AND month = 7 AND day = 28 AND transaction_type = 'withdraw' AND atm_location = 'Leggett Street')
    AND passport_number IN (SELECT passport_number FROM passengers WHERE flight_id IN (SELECT id FROM flights WHERE year = 2024 AND month = 7 AND day = 29 AND origin_airport_id = (SELECT id FROM airports WHERE city = 'Fiftyville') ORDER BY hour LIMIT 1)));
-- Suspect is Bruce

SELECT name FROM people WHERE phone_number IN (
    SELECT receiver FROM phone_calls WHERE caller =
        (SELECT phone_number FROM people WHERE name = 'Bruce') AND year = 2024 AND month = 7 AND day = 28 AND duration < 60);
-- Complice is Robin
