#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int values[] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

int main(void)
{
    // promt for input
    string player[2];
    player[0] = get_string("Player 1: ");
    player[1] = get_string("Player 2: ");

    // get scores
    int sum[2];

    for (int g = 0; g < 2; g++)
    {
        for (int i = 0; i < strlen(player[g]); i++)
        {
            int j = ((toupper(player[g][i])) -65);
            if (j >= 0 && j < 26)
            {
                sum[g] += values[j];
            }
        }
    }

    // decide winner
    if (sum[0] > sum[1])
    {
        printf("Player 1 wins!\n");
    }
    else if (sum[0] < sum[1])
    {
        printf("Player 2 wins!\n");
    }
    else
    {
        printf("Tie!\n");
    }
}
