 if int(person[subsq[1]]) == records[1] and int(person[subsq[2]]) == records[2] and int(person[subsq[3]]) == records[3]
