from cs50 import get_int

while True:
    h = get_int("How tall should the pyramid from 1 to 8 be? ")
    if h >= 1 and h <= 8:
        break

for i in range(h):
    i += 1
    print(" " * (h - i), end="")
    print("#" * i, end="")
    print("  ", end="")
    print("#" * i)
