from cs50 import get_int

number = get_int("Number: ")
front = number
while front >= 100:
    front //= 10
length = len(str(number))
sdig = 0
rest = 0
multi = 0

for i in range(length):
    rest += number % 10
    number //= 10
    sdig = 2 * (number % 10)
    if sdig > 9:
        multi += sdig % 10
        sdig //= 10
        multi += sdig
    else:
        multi += sdig
    number //= 10
summe = rest + multi
if summe % 10 == 0:
    if front == 37 or front == 39:
        if length == 15:
            print("AMEX")
        else:
            print("INVALID")
    elif front // 10 == 4:
        if length == 13 or length == 16:
            print("VISA")
        else:
            print("INVALID")
    elif front > 50 and front < 56:
        if length == 16:
            print("MASTERCARD")
        else:
            print("INVALID")
    else:
        print("INVALID")
else:
    print("INVALID")
