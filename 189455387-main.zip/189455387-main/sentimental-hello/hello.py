name = input("What's your name? ")
print(f"hello, {name}")
