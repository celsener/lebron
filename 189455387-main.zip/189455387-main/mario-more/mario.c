#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int n = 0;
    bool b = false;
    while (b == false)
    {
        n = get_int("How tall from 1 to 8 do you want the pyramid to be? ");
        if (n > 0 && n < 9)
        {
            b = true;
        }
    }
    for (int x = 1; x <= n; x++)
    {
        for (int g = n - x; g > 0; g--)
        {
            printf(" ");
        }
        for (int i = 0; i < 2; i++)
        {
            for (int j = 0; j < x; j++)
            {
                printf("#");
            }
            if (i < 1)
            {
                printf("  ");
            }
        }
        printf("\n");
    }
}
